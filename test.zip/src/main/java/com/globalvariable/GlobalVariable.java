package com.globalvariable;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GlobalVariable {
	public static WebDriver driver ;
	public static String product_title;
	public static String orderid;
	public static String updated_firstname;
	public static String updated_cellnumber;
	public static String firstname;
	public static String lastname;
	public static String address;
	public static String phone;
	public static String emailid;
	public static String newuser_firstname;
	public static String newuser_emailid;
	public static String newuser_phone;
	public static String companyNamechild;
	public static String reg_emailid;
	public static String returnid;
    }

